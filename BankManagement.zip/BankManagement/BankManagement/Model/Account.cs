﻿namespace BankManagement.Model
{
    public class Account
    {
        public int accountNumber { get; set; }
        public string accountOwnerName { get; set; }
        public int balance { get; set; }
        public string type { get; set; }
        public int userId {  get; set; }

        public Account(int accountNumber, string accountOwnerName, int balance, string type, int userId)
        {
            this.accountNumber = accountNumber;
            this.accountOwnerName = accountOwnerName;
            this.balance = balance;
            this.type = type;
            this.userId = userId;
        }
    }
}
