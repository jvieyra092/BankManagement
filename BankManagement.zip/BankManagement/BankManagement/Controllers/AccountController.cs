using Microsoft.AspNetCore.Mvc;
using BankManagement.Repositories;
using BankManagement.Repositories.Interfaces;
using BankManagement.Model;
namespace BankManagement.Controllers
{
    /*
    - Dependency Inject
- Logging & Exception Handling
- How to exposure secure/insecure endpoints

 

Bank Management Web API

    Bank Management Web API

 Banking with in-memory implementation for deposit, balance, and withdrawal
    */
    [ApiController]
    [Route("api/account")]
    public class AccountController : ControllerBase
    {
        IAccountRespository _accountRespository;
        public AccountController(IAccountRespository accountRespository)
        {
            _accountRespository = accountRespository;
        }

        [HttpGet]
        public async Task<IActionResult> GetBalance(int accountNumber, int userId)
        {
            
            var result = _accountRespository.GetAccount(accountNumber, userId);
            if (result == null) {
                return BadRequest();
            }

            return Ok(result);
        }

        [HttpPost]
        public IActionResult Withdraw(int accountNumber, int userId, int amount)
        {

            var result = _accountRespository.Withdraw(accountNumber, userId, amount);
            if (result == null)
            {
                return BadRequest();
            }

            return Ok(result);
        }
    }
}
