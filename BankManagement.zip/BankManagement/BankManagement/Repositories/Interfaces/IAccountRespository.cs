﻿using BankManagement.Model;


namespace BankManagement.Repositories.Interfaces
{
    public interface IAccountRespository
    {
        public Account? GetAccount(int accountNumber, int userId);
        public Account? Withdraw(int accountNumber, int userId, int amount);
    }
}
