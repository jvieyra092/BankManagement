﻿using BankManagement.Data;
using BankManagement.Model;
using BankManagement.Repositories.Interfaces;

namespace BankManagement.Repositories.Implementations
{
    public class AccountRespository: IAccountRespository
    {
        ApplicationDbContext _dbContext;
        public AccountRespository(ApplicationDbContext dbContext) { 
            _dbContext = dbContext;
        }
        public Account? GetAccount(int accountNumber, int userId)
        {
            return _dbContext.Get(accountNumber, userId);
        }

        public Account? Withdraw(int accountNumber, int userId, int amount)
        {
            var result = _dbContext.Withdraw(accountNumber, userId, amount);
            if (result != null) {
                _dbContext.SaveChanges();
            }
            return result;
        }
    }
}
