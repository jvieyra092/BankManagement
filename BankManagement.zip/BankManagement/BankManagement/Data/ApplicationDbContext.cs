﻿using Microsoft.EntityFrameworkCore;
using BankManagement.Model;

namespace BankManagement.Data
{
    public class ApplicationDbContext: DbContext
    {
        private List<Account> data;
        public ApplicationDbContext() { 
             data = new List<Account>();
            data.Add(new Account(1234, "Jon", 10, "checking", 1));
        }

        public Account? Get(int accountNumber, int userId)
        {

            var result = data.Where(a => a.accountNumber == accountNumber && a.userId == userId).FirstOrDefault();
            if (result == null) { 
                return null;
            }

            return result;
        }

        public Account? Withdraw(int accountNumber, int userId, int amount)
        {

            var result = data.Where(a => a.accountNumber == accountNumber && a.userId == userId).FirstOrDefault();

            if (result == null)
            {
                return null;
            }

            if (result.balance - amount >= 0)
            {
                result.balance = result.balance - amount;
            }
            else
            {
                return null;
            }
            

            return result;
        }

    }
}
