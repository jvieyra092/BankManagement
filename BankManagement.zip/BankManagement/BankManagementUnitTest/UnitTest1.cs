using BankManagement.Model;
using BankManagement.Repositories;
using BankManagement.Controllers;
using BankManagement.Repositories.Interfaces;
using BankManagement.Data;
namespace BankManagementUnitTest
{
    [TestClass]
    public class BankManagementUnitTest
    {
        IAccountRespository _accountRespository;
        ApplicationDbContext _dbContext;

        [TestInitialize]
        public void InitializeUnitTest(ApplicationDbContext dbContext, IAccountRespository accountRespository)
        {
            _dbContext = dbContext;
            _accountRespository = accountRespository;
        }

        [TestMethod]
        public void GetTestMethod()
        {
            AccountController accountController = new AccountController(_accountRespository);
            var result = accountController.GetBalance(1234, 1);

            Assert.IsNotNull(result);
            Account a = result.Result as Account;
            Assert.AreEqual(a.userId, 1);
            Assert.AreEqual(a.accountNumber, 1);
        }
    }
}